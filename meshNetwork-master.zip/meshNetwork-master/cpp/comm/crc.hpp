
#ifndef CRC_H
#define CRC_H

#include "comm/crc_8.hpp"
#include "comm/crc_16.hpp"

#endif      /* CRC_H */
