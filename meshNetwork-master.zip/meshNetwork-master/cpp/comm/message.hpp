#ifndef COMM_MESSAGE_HPP
#define COMM_MESSAGE_HPP

namespace comm {
    
    class Message {
        public: 
            virtual ~Message() {};    
    };    

}        
#endif // COMM_MESSAGE_HPP
