#include "node/nodeInterface.hpp"

namespace node {

    NodeInterface::NodeInterface() :
        nodeControlRunFlag(false)
    {}
    
}
