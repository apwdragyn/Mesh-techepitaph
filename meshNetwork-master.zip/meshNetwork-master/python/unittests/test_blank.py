class TestClass:
    
    def setup_method(self, method):
        pass        
    
    def test_method(self):
        """Test method."""
        pass    
        
