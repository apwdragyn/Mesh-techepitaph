from collections import namedtuple

CommandType = namedtuple('CommandType', ['packFormat', 'serialize', 'messageFormat', 'header']) 
